package androidGui;

import processing.core.PApplet;
import processing.core.PGraphics;

public class textBlock{
    BMScontrols Bms;
    PApplet applet;
    boolean parentCanvas;
    public boolean vertical,horizontal ;
    public float x,y,w,h,bx,by,bw,bh,offsetX,offsetY;
    public float tSize = 12;

    public String [] text;
    public String line;
    public int col;

    public textBlock(float x,float y,float w,float h){

        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        
        bx = x;
        by = y;
        bw = w;
        bh = h;

    };

    public textBlock(float x,float y,float w,float h,String[] s){

        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        
        bx = x;
        by = y;
        bw = w;
        bh = h;
        text = s;
    };

    public textBlock(float x,float y,float w,float h,String s){

        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        
        bx = x;
        by = y;
        bw = w;
        bh = h;
        line = s;
    };

    textBlock(){

    };

    public void draw(){
        if(text!=null)
        for(int i=0;i<text.length;i++){
            String s1 = text[i];
            applet.fill(0);
            applet.textSize(tSize);
            if(y + i*tSize - offsetY<y+h&&y + i*tSize - offsetY>0)applet.text(s1,x + offsetX,y + i*tSize - offsetY);

        }
    
    };

    public void draw(PGraphics canvas){
        //canvas.beginDraw();
        if(text!=null)
        for(int i=0;i<text.length;i++){
            String s1 = text[i];
            canvas.fill(col);
            canvas.textSize(tSize);
            if(y + i*tSize-offsetY<y+h&&y + i*tSize - offsetY>0)canvas.text(s1,x + offsetX,y + i*tSize - offsetY);
        }
        //canvas.endDraw();
    
    };

    public void draw(PGraphics canvas,boolean a){
        canvas.beginDraw();
        if(text!=null)
        for(int i=0;i<text.length;i++){
            String s1 = text[i];
            canvas.fill(col);
            canvas.textSize(tSize);
            if(y + i*tSize-offsetY<y+h&&y + i*tSize - offsetY>0)canvas.text(s1,x + offsetX,y + i*tSize - offsetY);
        }
        canvas.endDraw();
    
    };
};
