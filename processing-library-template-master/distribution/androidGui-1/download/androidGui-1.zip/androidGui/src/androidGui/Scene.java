package androidGui;

import java.util.ArrayList;
import java.util.HashMap;

import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;

class Scene extends Boundary{
	  PApplet applet;
	  BMScontrols Bms;
	  int id,gw = 25,gh = 20;
	  public float x,y,w,h;
	  public float bordersize = 1,limit;
	  public int cols = 40, rows = 30;
	  public String label;
	  public boolean showq,showf;
	  public boolean drag,resize,border = true,fill = true ,toggle,visible,clear;
	  public int col;
	  public int scol;
	  HashMap<String,Boolean> values = new HashMap<String,Boolean>();
	  ArrayList<Menu> menus = new ArrayList<Menu>();
	  ArrayList<Slider> sliders = new ArrayList<Slider>();
	  ArrayList<Button> buttons = new ArrayList<Button>();
	  ArrayList<Button> nav = new ArrayList<Button>();
	  //Boundary boundary;
	  
	  
	  PImage bgimage;
	  ArrayList<Quad> fields = new ArrayList<Quad>();
	  
	  
	  public Scene(float xx,float yy, float ww, float hh,BMScontrols bms){
	    
	    x = xx;
	    y = yy;
	    w = ww;
	    h = hh;
	    Bms = bms;
	    applet = bms.applet;
	    //main.Boundaries.add(new Boundary(x,y,w,h,4));
	    float gW = (w)/cols, gH = h/rows;
	    int k = gw;
	    
	    float sw = w /cols;
	    float sh = h / rows;
	    
	    for(int i=0;i<rows;i++){
	      for(int j=0;j<cols;j++){
	        
	        float X = x + (gW * j);  
	        float Y = y + (gH * i);
	        int ID = (j + i * cols);
	        
	        fields.add(new Quad(new PVector(X,Y),ID,gW,gH,this));
	        
	      }}
	    Bms.scenes.add(this);
	  };
	  
	  
	  Scene(){
		  
	  };
	  
	  void save(){
	    
	  };
	  
	  void load(){
	    
	  };
	  
	  void display(){
	    
		applet.noStroke();applet.fill(255);applet.rect(x,y,w,h);
		applet.strokeWeight(bordersize);
		applet.stroke(bg);if(!border){applet.noStroke();}
		applet.fill(bg);if(!fill)applet.noFill();
	    
		applet.rect(x,y,w,h);
	    
	  };
	  
	  void regression(){
	    
	  };
	  
	  void field(){
	    
	    for(int i=0;i<fields.size();i++){
	      
	      Quad q = fields.get(i);
	      
	      q.draw();
	      //q.setField();
	      //q.field();
	    }
	    
	  };
	  
	  boolean pos(){
	    return applet.mouseX>x&&applet.mouseX<x+w&&applet.mouseY>y&&applet.mouseY<y+h;
	  }
	  
	};
